//
//  Badger_award__V2Tests.swift
//  Badger award, V2Tests
//
//  Created by Zachary clayville on 5/6/25.
//

import Testing
@testable import Badger_award__V2

struct Badger_award__V2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
