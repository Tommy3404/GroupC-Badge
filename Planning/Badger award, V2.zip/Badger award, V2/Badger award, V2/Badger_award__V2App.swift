//
//  Badger_award__V2App.swift
//  Badger award, V2
//
//  Created by Zachary clayville on 5/6/25.
//

import SwiftUI

@main
struct Badger_award__V2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
